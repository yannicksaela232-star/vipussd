VIP USSD - app de envio (sem macro)

1. Abre a pasta VIPUssd no Android Studio (File > Open).
2. Espera o Gradle sincronizar.
3. Build > Build APK(s). Instala o APK no telemovel.
4. Abre a app, confirma o endereco do bot (http://127.0.0.1:3000) e toca em Iniciar.
5. Aceita as permissoes (SMS, chamadas, telefone e notificacoes).
6. Nao feches a app. Desativa a otimizacao de bateria para o VIP USSD.

Ligacao com o bot: o bot envia os pedidos para http://127.0.0.1:8080.
Arranca o bot com:  APP_URL=http://127.0.0.1:8080 pm2 restart bot --update-env

IMPORTANTE: as palavras-chave do menu do *162# (UssdEnvio.java, metodo responder)
sao um ponto de partida. Ajusta-as com os prints reais do menu.
