package com.vipshop.ussd;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int PEDIDO_PERMISSOES = 1;
    private TextView estado;
    private EditText endereco;

    @Override
    protected void onCreate(Bundle guardado) {
        super.onCreate(guardado);
        LinearLayout raiz = new LinearLayout(this);
        raiz.setOrientation(LinearLayout.VERTICAL);
        raiz.setPadding(48, 48, 48, 48);

        TextView titulo = new TextView(this);
        titulo.setText("VIP USSD - envio automatico");
        titulo.setTextSize(20);

        endereco = new EditText(this);
        endereco.setHint("Endereco do bot");
        endereco.setText(prefs().getString("bot", "http://127.0.0.1:3000"));

        Button iniciar = new Button(this);
        iniciar.setText("Iniciar");

        estado = new TextView(this);
        estado.setText("Parado");

        raiz.addView(titulo);
        raiz.addView(endereco);
        raiz.addView(iniciar);
        raiz.addView(estado);
        setContentView(raiz);

        iniciar.setOnClickListener(v -> {
            prefs().edit().putString("bot", endereco.getText().toString().trim()).apply();
            pedirPermissoes();
        });
    }

    private SharedPreferences prefs() {
        return getSharedPreferences("cfg", MODE_PRIVATE);
    }

    private void pedirPermissoes() {
        ArrayList<String> lista = new ArrayList<>();
        lista.add(Manifest.permission.RECEIVE_SMS);
        lista.add(Manifest.permission.CALL_PHONE);
        lista.add(Manifest.permission.READ_PHONE_STATE);
        if (Build.VERSION.SDK_INT >= 33) lista.add(Manifest.permission.POST_NOTIFICATIONS);
        requestPermissions(lista.toArray(new String[0]), PEDIDO_PERMISSOES);
    }

    @Override
    public void onRequestPermissionsResult(int codigo, String[] permissoes, int[] resultados) {
        super.onRequestPermissionsResult(codigo, permissoes, resultados);
        if (codigo != PEDIDO_PERMISSOES) return;
        Intent i = new Intent(this, BridgeService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        estado.setText("Ativo: a escutar SMS e a aguardar pedidos do bot.\nNao feches a app.");
    }
}
