package com.vipshop.ussd;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.telephony.TelephonyManager;

import java.util.Locale;
import java.util.Map;

/*
 * Envio de megas: *162# -> escolhe o menu -> numero -> quantidade -> confirmar.
 * AS PALAVRAS-CHAVE ABAIXO SAO UM PONTO DE PARTIDA. Tem de as ajustar
 * com os prints reais do menu do *162# no teu telemovel.
 */
public class UssdEnvio {
    private final Context ctx;
    private final int slot;
    private final String codigo, quantidade, numero, restantes;
    private final Handler h = new Handler(Looper.getMainLooper());
    private int passos = 0;
    private boolean fechado = false;

    UssdEnvio(Context ctx, int slot, Map<String, String> p) {
        this.ctx = ctx;
        this.slot = slot;
        this.codigo = p.get("codigo");
        this.quantidade = p.get("quantidade");
        this.numero = p.get("numero");
        this.restantes = p.get("restantes");
    }

    void executar() {
        String aviso = "";
        if (restantes != null && !restantes.isEmpty()) {
            if (restantes.equals("0")) aviso = " Esta foi a ultima transferencia deste cartao.";
            else if (restantes.equals("1")) aviso = " Falta 1 transferencia.";
            else aviso = " Faltam " + restantes + " transferencias.";
        }
        Voz.falar(ctx, "A transferir " + quantidade + " megabytes para " + Voz.digitos(numero) + "." + aviso);
        h.post(() -> enviar("*162#"));
        h.postDelayed(() -> fechar(false, "tempo esgotado"), 60000);
    }

    private void enviar(String texto) {
        try {
            TelephonyManager tm = Ussd.tm(ctx, slot);
            if (tm == null) { fechar(false, "SIM nao encontrado"); return; }
            tm.sendUssdRequest(texto, new TelephonyManager.UssdResponseCallback() {
                @Override
                public void onReceiveUssdResponse(TelephonyManager t, String req, CharSequence resp) {
                    responder(resp == null ? "" : resp.toString());
                }

                @Override
                public void onReceiveUssdResponseFailed(TelephonyManager t, String req, int falha) {
                    fechar(false, "falha USSD " + falha);
                }
            }, h);
        } catch (Exception e) {
            fechar(false, "erro: " + e.getMessage());
        }
    }

    private void responder(String t) {
        passos++;
        if (passos > 8) { fechar(false, "menu sem fim"); return; }
        String n = t.toLowerCase(Locale.ROOT);
        if (n.contains("sucesso") || n.contains("transferid") || n.contains("conclu")) { fechar(true, t); return; }
        if (n.contains("insuficiente") || n.contains("invalid") || n.contains("erro")) { fechar(false, t); return; }

        String resposta = null;
        if (n.contains("servi")) resposta = "8";
        else if (n.contains("numero") || n.contains("número")) resposta = numero;
        else if (n.contains("quantidade") || n.contains("megabyte") || n.contains("mb")) resposta = quantidade;
        else if (n.contains("confirm") || n.contains("1. sim") || n.contains("1 - sim")) resposta = "1";

        if (resposta == null) { fechar(false, "menu desconhecido: " + t); return; }
        enviar(resposta);
    }

    private void fechar(boolean ok, String info) {
        if (fechado) return;
        fechado = true;
        h.removeCallbacksAndMessages(null);
        Voz.falar(ctx, ok ? "Transferencia concluida." : "Falha na transferencia.");
        if (ok) {
            Bot.enviar(ctx, "/api/sucesso-ussd?codigo=" + Ussd.enc(codigo), null);
        } else {
            String motivo = info == null ? "" : (info.length() > 80 ? info.substring(0, 80) : info);
            Bot.enviar(ctx, "/api/erro-ussd?codigo=" + Ussd.enc(codigo) + "&motivo=" + Ussd.enc(motivo), null);
        }
    }
}
