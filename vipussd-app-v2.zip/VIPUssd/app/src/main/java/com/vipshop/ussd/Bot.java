package com.vipshop.ussd;

import android.content.Context;
import android.util.Log;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/* Ponte para o bot: envia SMS e resultados para o endereco guardado na app. */
public class Bot {
    static void enviar(Context c, String caminho, String corpo) {
        new Thread(() -> {
            try {
                String base = c.getSharedPreferences("cfg", Context.MODE_PRIVATE).getString("bot", "http://127.0.0.1:3000");
                HttpURLConnection con = (HttpURLConnection) new URL(base + caminho).openConnection();
                con.setRequestMethod("POST");
                con.setDoOutput(true);
                con.setConnectTimeout(5000);
                con.setReadTimeout(5000);
                con.setRequestProperty("Content-Type", "text/plain; charset=UTF-8");
                if (corpo != null) {
                    OutputStream os = con.getOutputStream();
                    os.write(corpo.getBytes("UTF-8"));
                    os.close();
                }
                int codigo = con.getResponseCode();
                Log.i("VIP", "bot " + caminho + " -> " + codigo);
                con.disconnect();
            } catch (Exception e) {
                Log.e("VIP", "bot: " + e);
            }
        }).start();
    }
}
