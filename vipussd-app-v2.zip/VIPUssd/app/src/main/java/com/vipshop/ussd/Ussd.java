package com.vipshop.ussd;

import android.content.Context;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;

import java.net.URLEncoder;

public class Ussd {
    /* slot 0 = SIM1, slot 1 = SIM2 */
    static TelephonyManager tm(Context c, int slot) {
        TelephonyManager base = (TelephonyManager) c.getSystemService(Context.TELEPHONY_SERVICE);
        if (slot == 0) return base;
        SubscriptionManager sm = (SubscriptionManager) c.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
        SubscriptionInfo info = sm.getActiveSubscriptionInfoForSimSlotIndex(slot);
        if (info == null) return null;
        return base.createForSubscriptionId(info.getSubscriptionId());
    }

    static String enc(String s) {
        try { return URLEncoder.encode(s == null ? "" : s, "UTF-8"); } catch (Exception e) { return ""; }
    }
}
