package com.vipshop.ussd;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;

/* Servidor local em 127.0.0.1:8080. O bot chama /SIM1, /SIM2 e /CONSULTA. */
public class BridgeService extends Service {
    private ServerSocket servidor;

    @Override
    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel canal = new NotificationChannel("vip", "VIP USSD", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(canal);
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, "vip")
                : new Notification.Builder(this);
        Notification n = b.setContentTitle("VIP USSD ativo")
                .setContentText("A aguardar pedidos do bot")
                .setSmallIcon(android.R.drawable.stat_notify_sync)
                .build();
        startForeground(1, n);
        iniciarServidor();
    }

    @Override
    public int onStartCommand(Intent i, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent i) {
        return null;
    }

    @Override
    public void onDestroy() {
        try { if (servidor != null) servidor.close(); } catch (Exception e) { }
        super.onDestroy();
    }

    private void iniciarServidor() {
        new Thread(() -> {
            try {
                servidor = new ServerSocket(8080, 50, InetAddress.getByName("127.0.0.1"));
                while (!servidor.isClosed()) {
                    Socket s = servidor.accept();
                    new Thread(() -> tratar(s)).start();
                }
            } catch (Exception e) {
                Log.e("VIP", "servidor: " + e);
            }
        }).start();
    }

    private void tratar(Socket s) {
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream(), "UTF-8"));
            String linha = in.readLine();
            OutputStream out = s.getOutputStream();
            out.write("HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 2\r\nConnection: close\r\n\r\nOK".getBytes("UTF-8"));
            out.flush();
            if (linha == null) return;
            String[] p = linha.split(" ");
            if (p.length < 2) return;
            String caminho = p[1];
            int q = caminho.indexOf('?');
            String rota = q >= 0 ? caminho.substring(0, q) : caminho;
            Map<String, String> params = parametros(caminho);
            Log.i("VIP", "pedido: " + rota);
            if (rota.equals("/SIM1")) new UssdEnvio(this, 0, params).executar();
            else if (rota.equals("/SIM2")) new UssdEnvio(this, 1, params).executar();
            else if (rota.equals("/CONSULTA")) new UssdConsulta(this, 0).executar();
        } catch (Exception e) {
            Log.e("VIP", "pedido: " + e);
        } finally {
            try { s.close(); } catch (Exception e) { }
        }
    }

    private static Map<String, String> parametros(String caminho) throws Exception {
        Map<String, String> m = new HashMap<>();
        int q = caminho.indexOf('?');
        if (q < 0) return m;
        for (String par : caminho.substring(q + 1).split("&")) {
            int i = par.indexOf('=');
            if (i > 0) m.put(par.substring(0, i), URLDecoder.decode(par.substring(i + 1), "UTF-8"));
        }
        return m;
    }
}
